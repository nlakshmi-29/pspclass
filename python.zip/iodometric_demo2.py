
is_generic_name = False
name = 'Tom'
if name == 'Tom' or name == 'Dick' or name == 'Harry':
  is_generic_name = True
  print(is_generic_name)

#iodometric statement

name = 'Tom'
is_generic_name = name in ('Tom', 'Dick', 'Harry')
  
