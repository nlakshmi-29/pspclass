'''

Tuples are identical to lists in all respects,except for the following properties:
1. Tuples are defined by enclosing the elements in parenthesis( () ).
2. Tuples are immutable.

#Define a tuple
student =("prasanna","geethika","keerthi","jyothika","sushma")
print(type(student))
for i in student:
    print(i)

student =("prasanna","geethika","keerthi","jyothika","sushma")
print(student[0:3])

# What are the benifits of using tuples instead of lists in python


student =("prasanna","geethika","keerthi","jyothika","sushma")#tuple packing

#(s1,s2,s3,s4,s5) = student      #tuple unpacking
#print(s1)
#print(student)

'''
student =("prasanna","geethika","keerthi","jyothika","sushma")
student_1 = ("prasanna","geethika","keerthi","jyothika","sushma")
print(type(student))
print(student_1)
