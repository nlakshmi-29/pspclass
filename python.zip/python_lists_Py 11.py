students = ["prasanna", "keerthika", "raju", "harsha", "bhuvi"]
student_info = ["prasanna",29,9.4,"ECE",["chemistry", "psp", "maths"]]
'''
print(type(students))
print(students)
print(type(student_info))
print(student_info)

#list slicing:
#print(students[0:4])
#print(students[:4])


#print(students[2:-1])

#print(student_info)

#print(student_info[-1])

#print(student_info[-1][1])

print(student_info[-1][2])

#appending list elements

students.append("lucky")
print(students)

#modification of list
students[1] = "raghu"
print(students)

#length of a list
#print(len(students))

#removing an element from the list
students.pop(3)
print(students)

#find the index value of an element in the list

raju_index = students.index("raju")
print(raju_index)
'''

for element in students:
    print(element)

