# A Dictionary in python is the unordered and changeable collection of data values that holds key-value pairs.
# A Dictionary in python is declared by enclosing a comma-seperated list of key-value pairs using curly braces({}).
# Syntax for python dictionary
'''
student1 ={'Name': 'Prasanna','branch':'ECE','section':'A','Roll_no':29}
print(type(student1))
print(student1)

student1 ={'Name': 'Prasanna','branch':'ECE','section':'A','Roll_no':29,'Name':'Prasanna'}
print(student1)

student1 ={'Name': 'Prasanna','branch':'ECE','section':'A','Roll_no':29}
print(student1['Name'])
print(student1['Roll_no'])
student1 ={'Name': 'Prasanna','branch':'ECE','section':'A','Roll_no':29}
print("Before updating")
print(student1)

#'Member':'NCC'

student1.update({'Member':'NCC'})
print("After updating")
print(student1)
'''
#Delete keys from the dictionary
student1 ={'Name': 'Prasanna','branch':'ECE','section':'A','Roll_no':29}
print("Before deleting")
print(student1)
del student1['Name']
print("After deleting")
print(student1)
