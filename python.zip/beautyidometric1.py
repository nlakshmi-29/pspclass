
colors = ['red','blue','green','pink']
for i in range(len(colors)):
  print(i,'--->',colors[i])


for i , colors in enumerate(colors):
  print(i,'-->',colors[i])
