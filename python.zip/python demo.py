Python 3.9.5 (tags/v3.9.5:0a7dcbd, May  3 2021, 17:27:52) [MSC v.1928 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> print("Hello world")
Hello world
>>> 
==================================================== RESTART: C:/Users/nande/Desktop/python demo/demo.py ====================================================
0
1
2
3
4
5
6
7
8
9
>>> b=5
>>> print(b)
5
>>> print("b= ",b)
b=  5
>>> print(type(b))
<class 'int'>
>>> a=10
>>> print(a)
10
>>> type(a)
<class 'int'>
>>> a="Hello"
>>> print(a)
Hello
>>> type(a)
<class 'str'>
>>> a = 3.14
>>> print(a)
3.14
>>> type(a)
<class 'float'>
>>> a = [2,4,6,8]
>>> print(a)
[2, 4, 6, 8]
>>> type(a)
<class 'list'>
>>> a = (1,3,5,7)
>>> print(a)
(1, 3, 5, 7)
>>> type(a)
<class 'tuple'>
>>> a = '*'
>>> type(a)
<class 'str'>
>>> 