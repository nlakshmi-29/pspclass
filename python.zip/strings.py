'''
#len ()
s1=len("prasanna")
print(s1)

#space in between the double colons is also counted

s2 = len(" ")
print(s2)

s3 = len("")
print(s3)

#empty string

s4 = ' '
print(type(s4))
'''
#usage of " " and ' ' in same statement
p = (" I'm learning python ")
print(p)
p  = (' I'm learning python ') #invalid syntax

  

