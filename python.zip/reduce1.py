#lambda in reduce()

from functools import reduce
even_list = [2,4,6,8,10]
product = reduce(lambda x,y: x*y, even_list)
print(product)
