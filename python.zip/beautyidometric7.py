# example(7)-usiing of list in differnt way

student=("prasanna","keerthi","geetu","jyothi")
print(student[0:3])

student=("prasanna","keerthi","geetu","jyothi")
print(student[:3])

