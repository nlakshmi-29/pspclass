import arithmetic_functions
x = int(input("Enter first number:"))
y = int(input("Enter second number:"))
z = arithmetic_functions.div(x,y)

print("The div of x and y is:%d"%(z))
