# -*- coding: utf-8 -*-
"""
Created on Mon Jun 28 17:47:07 2021

@author: nande
"""

#import numpy as np
#array = np.array([[1,2,3,4],[5,6,7,8],[9,10,11,12],[13,14,15,16]])
#print(array)
#print(array.shape)

import numpy as np
array = np.array([[1,2,3],[4,5,6],[7,8,9],[10,11,12]])
print(array)
print(array.shape)

#TO PRINT ALL ELEMENTS IN A SINGLE MATRIX
import numpy as np
a = np.array([[1,2,3],[4,5,6],[7,8,9],[10,11,12]])
print(a.ravel())
