#If statements

(x,y,z) = (8,9,10)
if x <= y and y <= z:
  print("true")
  


#idometric

if x <=y <=z:
  print("true")

