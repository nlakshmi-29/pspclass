# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
import numpy as np
array = np.array([[1,2,3],[4,5,6]])
print(array)
print(array.shape)
print(len(array))
print(array[0,1])
#it was hard one(my)
#print(array[0,[0,1,2]])
#this is the idiomatic one.(:indicates all).
print(array[0,:])
print(array[:,1])


