students = ["prasanna", "keerthika", "raju", "harsha", "bhuvi"]
student_info = ["prasanna",29,9.4,"ECE",["chemistry", "psp", "maths"]]
print(type(students))
print(students)
print(type(student_info))
print(student_info)
