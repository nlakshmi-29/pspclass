i = ["blue":"green":"yellow"]
print(len(i))
