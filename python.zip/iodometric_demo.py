name = 'Prasanna'
address = 'New York, NY'
if name:
  print(name)
print(address)

#iodometric

name = 'Prasanna'
address = 'New York, NY'
if name:
   print(name)
   print(address)
