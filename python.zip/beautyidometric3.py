
colors = ['red','blue','green','pink']
names = ['apple','sky','leaf','flower']

n = min(len(names),len(colors))
for i in range(1):
  print(names[i],'-->',colors[i])

  for name,color in zip(names,colors):
    print(name,'-->',color)
