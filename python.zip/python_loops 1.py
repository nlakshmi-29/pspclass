#for loop
even = [2,4,6,8,10,12,14,16,18,20]
for i in even:
    if i>10:
        break
    print(i)
