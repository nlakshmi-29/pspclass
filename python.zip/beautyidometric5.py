 
#Looping over dictionary keys

d = {'matthew': 'blue', 'rachel': 'green', 'raymond': 'red'}

for i in d.keys():
    print(i)
 
d = {'matthew': 'blue', 'rachel': 'green', 'raymond': 'red'}


for i in d.keys():
    if i.startswith('m'):
         print(i)
