#slicing
subject1='problem'
subject2='solving'
subject3='and'
subject4='programming'
subject=subject1+subject2+subject3+subject4
#print(subject[0:7])

#Raw operator --- memebership

print(" prints \n")

