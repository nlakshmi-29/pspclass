#sorted list
names = ['prasanna' , 'keerthi' , 'geetu' , 'jyothi']
for names in sorted(names):
    print(names)
    
names = ['prasanna' , 'keerthi' , 'geetu' , 'jyothi']
print(sorted(names, key = len))
