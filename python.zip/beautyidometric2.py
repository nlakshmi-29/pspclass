
colors = ['red','blue','green','pink']
for i in range (len(colors)-1,-1,-1):

 print (colors [i] )
 for color in reversed(colors):
     print(color)
