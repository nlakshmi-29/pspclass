#for loop
even = [2,4,6,8,10,12,14,16,18,20]
print(type(even))
for i in even:
    if i!=10:
        continue
    print(i)
