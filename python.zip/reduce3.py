'''
#lambda in reduce()

from functools import reduce
even_list = [2,4,6,8,10]
product = reduce(lambda x,y: x*y, even_list)
print(product)

add=reduce(lambda x,y: x+y, even_list)
print(add)

squares=reduce(lambda x,y: x, even_list)
print(squares)
'''

#Recursion

def fact(n):
    if n==0:
        return 1
    else:
        return n*fact(n-1)
print(fact(5))
