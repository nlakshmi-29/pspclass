for i in (0 , 1 , 2 , 3 , 4 , 5):
  print (i ** 2)

for i in range (6):
  print(i**2)


