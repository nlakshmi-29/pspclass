name1 ="prasanna"
print(name1)
print(type(name1))
