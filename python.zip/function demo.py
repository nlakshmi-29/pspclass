'''
A function in python is a piece of code which runs when it is referenced.
It is used to utilise the code in more than one place in a program.in-built functions,user defined functions
print(),input()
'''
def add(x,y):
    return x+y
x=3
y=4
z=add(x,y)
print("z=",z)
