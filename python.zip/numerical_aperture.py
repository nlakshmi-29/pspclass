import math
def numerical_aperture(d,l):
  return (d) / math.sqrt((d**2)+(4)*(l**2))
