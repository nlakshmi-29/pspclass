name2 ='prasanna lakshmi'
print(name2)
print(type(name2))

