Python 3.9.5 (tags/v3.9.5:0a7dcbd, May  3 2021, 17:27:52) [MSC v.1928 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> a=(2,4,6,8)
>>> a
(2, 4, 6, 8)
>>> type(a)
<class 'tuple'>
>>> b=[1,3,5,7]
>>> b
[1, 3, 5, 7]
>>> type(b)
<class 'list'>
>>> a="Hello"
>>> b='hello'
>>> a==b
False
>>> a="Hello"
>>> b='Hello'
>>> a==b
True
>>> a!b
SyntaxError: invalid syntax
>>> a!=b
False
>>> c=30
>>> d=50
>>> c>d
False
>>> c**d
71789798769185258877024900000000000000000000000000000000000000000000000000
>>> import math
>>> math.factorial(5)
120
>>> 