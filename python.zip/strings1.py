#usage of \n,\t,\\,\',\"

s = " my\tname\tis\tprasanna "
print(s)

p = " my\nname\nis\nprasanna "
print(p)

p =('I\'m learning python')
print(p)

r = ("hey \"how do u do!\"")
print(r)

