name = ''
address = 'New York, NY'
if name:
  print(name)
print(address)

#iodometric

name = ''
address = 'New York, NY'
if name:
   print(name)
   print(address)
   print(type(name))
