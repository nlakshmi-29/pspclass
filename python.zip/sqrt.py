# -*- coding: utf-8 -*-
"""
Created on Mon Jul 12 21:35:48 2021

@author: nande
"""

import math
def square(n, i, j):
    mid = (i + j) / 2;
    mul = mid * mid;
    if ((mul == n) or (abs(mul - n) <0.00001)):
        return mid;
    
    elif (mul < n):
        return square(n, mid, j);
    
    else:
        return square(n, i, mid);