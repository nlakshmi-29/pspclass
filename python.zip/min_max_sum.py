# -*- coding: utf-8 -*-
"""
Created on Tue Jun 29 10:09:30 2021

@author: nande
"""

import numpy as np
a = np.array([1,2,3])
print(a.max())
print(a.min())
print(a.sum())