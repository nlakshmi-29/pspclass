'''

Tuples are identical to lists in all respects,except for the following properties:
1. Tuples are defined by enclosing the elements in parameters( () ).
2. Tuples are immutable.
'''
#Define a tuple
student =("prasanna","keerthi","raju","harsha","bhuvi")
print(type(student))
for i in student:
    print(i)
