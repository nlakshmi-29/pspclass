import arithmetic_functions
x = int(input("Enter first number:"))
y = int(input("Enter second number:"))
z = arithmetic_functions.add(x,y)

print("The sum of x and y is:%d"%(z))
