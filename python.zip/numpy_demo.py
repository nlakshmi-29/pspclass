#Generate some random data
import numpy as np
data = np.random.randn(2,3)
print("data= ",data)
