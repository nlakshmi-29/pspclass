# -*- coding: utf-8 -*-
"""
Created on Tue Jun 29 10:49:24 2021

@author: nande
"""

#import numpy as np
#a = np.array([(1,2,3,4),(4,5,6,7)])
#a = a.reshape(4,2)
#print(a)

#import  numpy as np
#a = np.array([(1,2,3,4),(3,4,5,6),(6,7,8,9)])
#print(a[0:2,2])

#import numpy as np
#a = np.linspace(1,8,5)
#print(a)

#ADDING OF MATRIX ELEMENTS
#import numpy as np
#a = np.array([(1,2,3),(4,5,6)])
#print(a.sum(axis=0))
#print(a.sum(axis=1))

#SQUARE ROOT OF EACH ELEMENT
#import numpy as np
#a = np.array([(1,4,9),(16,25,36)])
#print(np.sqrt(a))

#import numpy as np
#a = np.array([(1,2,3),(4,5,6)])
#b = np.array([(4,5,8),(6,9,7)])
#print(a+b)
#print(a-b)
#print(a*b)
#print(a/b)

import numpy as np
a = np.array([(1,2,3),(4,5,6)])
b = np.array([(4,5,8),(6,9,7)])
print(np.vstack((a,b)))
print(np.hstack((a,b)))
